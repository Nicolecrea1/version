document.getElementsByTagName("h1")[].style.fontSize = "6vw

